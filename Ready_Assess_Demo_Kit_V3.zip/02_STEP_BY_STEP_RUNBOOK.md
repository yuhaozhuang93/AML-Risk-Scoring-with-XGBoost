# Claude Desktop — Ready Assess Demo: Step-by-Step Runbook

## Before you start
Create a Claude Project named:
**Ready Assess 2026 GenAI Demo**

Add to Project Context:
1. 2024 Final Ready Assess Report
2. 2026 Mock Ready Assess Workbook
3. Optional supporting evidence/methodology files

Paste `01_CLAUDE_PROJECT_INSTRUCTIONS.md` into Project Instructions.

---

# STEP 4 — Workbook Structure Discovery
Use Chat 01: `01 - Source Understanding & Fact Packet`

Paste:

> I want to establish the workbook structure before any report generation. The workbook uploaded to this Project is a **mock current-year Ready Assess dataset containing fake/demo data**. Do not treat any values as production data.
>
> Do NOT generate the report. Do NOT create the Fact Packet yet. Do NOT create an Artifact yet.
>
> Re-read the entire current-year mock workbook from top to bottom. Do not stop after the Executive Summary.
>
> Identify all available Executive Summary data, Assessment Units, YoY Inherent Risk history, YoY Mitigating Controls history, YoY Residual Risk history, Overall Risk Assessment Results, Inherent AML Risk, Customer Base Risk, Geographies Risk, Products and Services Risk, Distribution Channels Risk, Other Qualitative Risk, BSA/AML Mitigating Controls, risk factors/sub-factors, ratings, scores, weights, calculated scores, overall ratings, customer counts, country/customer distributions, product-level customer counts, transaction counts, transaction amounts, and other supporting quantitative data.
>
> Do this separately for Mizuho Bank, MSUSA, MCM, and MUSO where applicable.
>
> Represent the workbook hierarchy as:
> `Assessment Unit → Risk Category → Risk Factor → Risk Sub-Factor → Rating / Score / Weight → Supporting Quantitative Data`
>
> For each major section provide Assessment Unit, Section, Subsection/Risk Factor, Data Available, Source Sheet, approximate cell/range if identifiable, and classify the data as input, calculated result, supporting fact, or summary output.
>
> Explain only workbook-supported roll-up relationships. Do not infer calculations that are not supported by structure/formulas.
>
> Finish with a Coverage Check: successfully identified sections, unclear sections, data that does not fit the hierarchy, potential duplicates/conflicts, and missing sections by Assessment Unit.
>
> **Do not map to the historical report yet.**

Review Claude's output before proceeding.

---

# STEP 5 — 2024 Historical Report Understanding

> We have now established the structure of the 2026 mock current-year workbook.
>
> Before creating the Fact Packet, analyze the 2024 Final Ready Assess Report independently.
>
> Important source distinction:
> - The 2024 Final Ready Assess Report is the historical report reference.
> - The 2026 mock workbook is the current-year assessment source.
> - Historical YoY columns inside the 2026 mock workbook are supporting historical comparison data only.
> - There is no 2025 Final Report available in this Project.
> - Do not infer or reconstruct a 2025 Final Report.
>
> Do not generate the Fact Packet or 2026 report yet.
>
> Identify the report section hierarchy, Assessment Units, Executive Summary structure, Inherent Risk sections, Mitigating Controls sections, Residual Risk sections, risk factors discussed, tables, quantitative metrics, explanations supporting ratings, methodology language, and reusable narrative patterns.
>
> Separate content into:
> **A. STRUCTURE / TEMPLATE**
> **B. HISTORICAL FACT**
> **C. HISTORICAL EXPLANATION**
>
> Do not assume historical facts/explanations remain valid for 2026.
>
> Produce:
> 1. 2024 Report Structure Map
> 2. Historical Facts Inventory
> 3. Historical Explanation Inventory
> 4. Potentially Reusable Template Language
> 5. Items that must be refreshed for the 2026 report

---

# STEP 6 — Source-to-Report Mapping

> Now map the 2026 mock workbook data model to the 2024 Final Ready Assess Report structure.
>
> Do not generate report prose yet.
>
> For every major report section identify:
> - Report section
> - Purpose
> - 2024 historical facts used
> - Corresponding 2026 workbook section
> - Current-year rating source
> - Current-year supporting quantitative data
> - Relevant risk factors/sub-factors
> - Workbook YoY data available
> - Whether sufficient evidence exists to refresh the section
>
> Build:
> `Report Section | 2024 Content Purpose | 2026 Source | Current Rating Source | Supporting Metrics | YoY Available | Evidence Status | Refresh Required`
>
> Evidence Status values:
> `SUFFICIENT`, `PARTIAL`, `SME_INPUT_REQUIRED`, `NOT_APPLICABLE`
>
> Do not assume similar terminology means fields are equivalent. Flag uncertain mappings.
>
> Finish with successfully mapped sections, partially mapped sections, unmapped sections, missing evidence, and mapping uncertainties.
>
> Do not generate the Fact Packet yet.

---

# STEP 7 — Generate Fact Packet

> Using the validated Workbook Data Map and Source-to-Report Mapping, create the 2026 Ready Assess Fact Packet.
>
> The Fact Packet must contain facts and evidence only. Do not write report narrative.
>
> Organize:
> `Assessment Unit → Risk Category → Risk Factor → Risk Sub-Factor`
>
> Where applicable capture:
> assessment_unit, risk_category, risk_factor, risk_sub_factor, current_rating, risk_score, weight, calculated_score, overall_rating, supporting_metrics, customer_count, transaction_count, transaction_amount, country_or_jurisdiction_data, workbook_yoy_history, 2024_report_reference, source_file, source_sheet, source_cell_or_range, report_sections_affected, evidence_status, reviewer_status.
>
> Workbook YoY values are workbook-supplied historical comparison data only. Do not claim they are independently verified unless a final report is available.
>
> Store relevant 2024 facts separately as `2024_report_reference`. Do not copy 2024 explanations into current-year facts.
>
> If a current rating/metric exists but evidence is insufficient to explain why it changed, set:
> `evidence_status = SME_INPUT_REQUIRED`
>
> Never invent explanations.
>
> Present a human-readable Fact Packet followed by:
> **Change Summary**
> **Evidence Exceptions**
> **SME Input Required**
> **Source Traceability Summary**

---

# STEP 8 — Validate Fact Packet

> Before building the Artifact, validate the Fact Packet against the source files.
>
> For every Fact Packet record verify Assessment Unit, Risk Category, Risk Factor, Risk Sub-Factor, Current Rating, Risk Score, Weight, Calculated Score, Overall Rating, Customer Count, Transaction Count, Transaction Amount, YoY values, and Source reference directly against the 2026 mock workbook.
>
> Separately verify any `2024_report_reference` against the 2024 Final Ready Assess Report.
>
> Do not use the 2024 report to override current-year workbook values.
>
> Identify exact matches, missing facts, source mismatches, conflicting values, unsupported facts, potential extraction errors, and potential calculation inconsistencies.
>
> Do not silently correct conflicts.
>
> Produce a QA Exception List and conclude with either:
> `FACT PACKET READY FOR REVIEW`
> or
> `FACT PACKET REQUIRES CORRECTION`
>
> If correction is required, identify the exact records.

Spot-check several anchor values yourself before continuing.

---

# STEP 9 — Build Artifact
Start a new Project chat:
`02 - Ready Assess Review Artifact`

Use `03_BUILD_ARTIFACT_PROMPT.md`.

Iterate the Artifact in chat rather than rebuilding from scratch. Useful follow-ups:
- `Make the main view more executive-friendly; move technical source metadata into expandable details.`
- `Make changed ratings easier to identify without excessive color.`
- `Render all sections dynamically from the Fact Packet rather than hard-coding categories.`
- `Add a drill-down from Assessment Unit to Risk Factor to supporting metrics.`
- `Add an Exceptions queue for SME_INPUT_REQUIRED, mapping uncertainty, and source conflicts.`

---

# STEP 10 — Generate 2026 Draft Report

> Using only the validated 2026 Fact Packet for current-year factual content, generate a draft 2026 Ready Assess report.
>
> Use the 2024 Final Ready Assess Report only as a reference for report organization, section sequence, professional tone, terminology, table style, and general narrative pattern.
>
> Do NOT treat the 2024 report as the source of current-year facts.
>
> Every current-year rating, risk score, percentage, customer count, transaction count, transaction amount, country/jurisdiction statement, and quantitative claim must be grounded in the validated 2026 Fact Packet.
>
> Historical statements may be included only when source and year are clear.
>
> Do not copy a 2024 explanation merely because the current rating is the same.
>
> If sufficient current-year evidence exists, generate updated narrative from that evidence.
>
> If evidence is insufficient, insert:
> `[SME INPUT REQUIRED]`
>
> Preserve traceability between each generated section and Fact Packet records.
>
> Label the output:
> `DRAFT FOR REVIEW — MOCK / SYNTHETIC DATA`

---

# STEP 11 — End-to-End QA

> Perform an end-to-end factual QA of the generated 2026 Ready Assess draft.
>
> Validate:
> `2026 Mock Workbook → Fact Packet → Artifact → Generated Report`
>
> Use the 2024 Final Report only as historical/template reference.
>
> For every factual statement determine whether it is supported by a validated current-year Fact Packet record, a clearly identified historical source, or SME input.
>
> Verify ratings, risk scores, weights, percentages, customer counts, transaction counts, transaction amounts, YoY statements, and risk explanations.
>
> Flag unsupported statements, hallucinated explanations, stale 2024 facts, incorrect YoY claims, source mismatches, contradictions, and missing SME placeholders.
>
> Do not silently repair the report.
>
> Produce:
> 1. QA Summary
> 2. Exception List
> 3. Source Traceability Check
> 4. Sections Ready for Review
> 5. Sections Requiring SME Input

---

# Recommended 10-minute office demo
Do NOT build from scratch live.
1. PPT: explain why direct prompt → report is difficult to validate.
2. Project Context: show 2024 report + 2026 mock workbook + Instructions.
3. Workbook Understanding: show one hierarchy/roll-up example.
4. Artifact: drill from Assessment Unit → Risk Factor → supporting metrics.
5. Exception: show an SME_INPUT_REQUIRED case.
6. Report Preview: show a grounded draft section.
7. Close: AI extracts/structures; human reviews; AI generates.
