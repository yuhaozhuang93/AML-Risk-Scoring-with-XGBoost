# OFFICE QUICK START

1. Create/Open Project: **Ready Assess 2026 GenAI Demo**
2. Project Instructions → paste `01_CLAUDE_PROJECT_INSTRUCTIONS.md`
3. Context → upload:
   - 2024 Final Ready Assess Report
   - 2026 Mock Ready Assess Workbook
4. Chat 01 → follow `02_STEP_BY_STEP_RUNBOOK.md`, Steps 4–8.
5. Do not continue if Step 8 says `FACT PACKET REQUIRES CORRECTION`.
6. New Chat 02 → paste `03_BUILD_ARTIFACT_PROMPT.md`.
7. Iterate Artifact.
8. Return to runbook for Steps 10–11.
9. Demo from the prebuilt state; do not build everything live.

Key story:
**Understand → Map → Extract → Validate → Review → Generate → QA**
