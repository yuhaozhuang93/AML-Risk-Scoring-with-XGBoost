# Build Artifact Prompt — Ready Assess Review & Report Generator

Using the validated Ready Assess Fact Packet and Project source files, build an interactive Artifact named:

**Ready Assess Review & Report Generator**

## Demo status
This prototype uses MOCK / SYNTHETIC DATA.
Display prominently:
`MOCK / SYNTHETIC DATA — DEMONSTRATION ONLY`

## Purpose
The Artifact is a human review and control layer between fact extraction and report generation. It is not a generic dashboard and it must not invent missing explanations.

## 1. Executive Summary
Show Assessment Units with:
- Inherent Risk
- Mitigating Controls
- Residual Risk
- Review Status
- Evidence Exceptions

Use a layout similar to the workbook: Assessment Units as rows and major risk outcomes as columns.

## 2. Workbook YoY Risk View
Display workbook-provided historical ratings across all available years.

Label this explicitly:
`Workbook YoY History`

Do not imply every historical value has been independently verified against a final historical report.

Allow filtering by Assessment Unit and risk type.

## 3. Risk Drill-Down
Support navigation:
`Assessment Unit → Risk Category → Risk Factor → Risk Sub-Factor`

Where available display:
- Current Rating
- Risk Score
- Weight
- Calculated Score
- Overall Rating
- Supporting Metrics
- Customer Count
- Transaction Count
- Transaction Amount
- Country / Jurisdiction Data
- Source

The user should be able to move from a high-level result down to the facts supporting it.

## 4. Change Review
Highlight current-year changes and show:
- Historical/workbook comparison value
- Current value
- Supporting evidence
- Report section(s) affected
- Evidence status

Do not rely on red font alone. Formatting is only a possible change signal.

## 5. Exceptions / SME Input
Create a prominent exception queue for:
- `SME_INPUT_REQUIRED`
- Missing evidence
- Mapping uncertainty
- Conflicting sources
- Potential extraction errors
- Potential calculation inconsistencies

Never generate an explanation simply to close an exception.

## 6. Source Traceability
For every material fact, allow reviewers to inspect:
- Source file
- Sheet/page
- Cell/range or section when identifiable
- Fact Packet record used

Keep source details available through expandable details so the executive view remains uncluttered.

## 7. 2024 Historical Reference
Where useful, allow the reviewer to see clearly labeled 2024 historical report references.

Never display a 2024 fact as if it were a current-year fact.
Never assume a 2024 explanation remains valid because the rating is unchanged.

## 8. Report Preview
Provide a Generated Report Preview that uses only validated current-year Fact Packet content for current-year facts.

Use the 2024 Final Ready Assess Report only for:
- structure
- section order
- terminology
- professional tone
- table/narrative pattern

When evidence is insufficient, show:
`[SME INPUT REQUIRED]`

Label report content:
`DRAFT FOR REVIEW`

## Review actions
Include:
- Approve
- Needs Revision
- SME Input Required
- Reset Review

Also show:
- total exceptions
- items pending review
- approved items

## Design
Use a restrained banking/compliance leadership style:
- clean
- professional
- minimal clutter
- clear information hierarchy
- easy drill-down
- changes visible without excessive color
- exceptions prominent
- source details accessible but secondary

Prefer dynamic rendering from the Fact Packet rather than hard-coded risk categories so additional workbook sections can be added later.

## Critical guardrails
- Never invent causal explanations.
- Never invent percentages/counts.
- Never silently resolve source conflicts.
- Never treat workbook formatting as the business fact.
- Never reconstruct a nonexistent 2025 Final Report.
- Never use a historical explanation as current-year evidence without current-year support.
